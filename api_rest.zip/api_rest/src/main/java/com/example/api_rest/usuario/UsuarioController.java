package com.example.api_rest.usuario;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "api/v1/usuario")
public class UsuarioController {

    private final UsuarioService usuarioService;

    @Autowired
    public UsuarioController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @GetMapping
    public List<Usuario> getUsuarios(){
        return usuarioService.getUsuarios();
    }

    @PostMapping
    public void registrarNuevoUsuario(@RequestBody  Usuario usuario){
        usuarioService.agregarNuevoUsuario(usuario);
    }

    @DeleteMapping(path = "{id_usuario}")
    public void borrarUsuario(@PathVariable("id_usuario") Integer id_usuario){
        usuarioService.borrarUsuario(id_usuario);
    }

//    @GetMapping(path = "{email_usuario}/{password_usuario}" )
//    public List<Usuario> getUsuarioLogin(@PathVariable String email_usuario, @PathVariable String password_usuario ){
//        return usuarioService.getUsuariosLogin();
//    }

}
