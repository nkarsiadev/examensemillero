package com.example.api_rest.usuario;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class UsuarioConfig {

    @Bean
    CommandLineRunner commandLineRunner(UsuarioRepository repository){
        return args -> {
            Usuario marco = new Usuario(
                    1718018870,
                    "Marco",
                    "Clavijo",
                    "clavijo@hotmail.com",
                    "abc123",
                    26,
                    true,
                    1
            );

            Usuario nelson = new Usuario(
                    1718014410,
                    "nelson",
                    "neow",
                    "nelson@hotmail.com",
                    "abc123",
                    16,
                    true,
                    1
            );
            Usuario alex = new Usuario(
                    1718014510,
                    "alex",
                    "alex",
                    "alex@hotmail.com",
                    "abc123",
                    16,
                    true,
                    1
            );

            repository.saveAll(
                    List.of(marco,nelson,alex)
            );
        };
    }
}
