
package com.example.api_rest.usuario;

import com.example.api_rest.roles.Roles;

import javax.persistence.*;

@Entity
@Table

public class Usuario {

    @Id
    @SequenceGenerator(
            name="secuencia_usuario",
            sequenceName = "secuencia_usuario",
            allocationSize = 1
    )
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "secuencia_usuario"
    )

    private Integer id_usuario;
    private String name_usuario;
    private String last_name_usuario;
    private String email_usuario;
    private String password_usuario;

    private Integer edad;
    private boolean status;
    private Integer id_rol;

    @ManyToOne
    @JoinColumn(name = "rol_id_id_rol")
    private Roles rol_id;

    public Roles getRol_id() {
        return rol_id;
    }

    public void setRol_id(Roles rol_id) {
        this.rol_id = rol_id;
    }

    public Usuario() {
    }

    public Usuario(Integer id_usuario, String name_usuario, String last_name_usuario, String email_usuario, String password_usuario, Integer edad, boolean status, Integer id_rol) {
        this.id_usuario = id_usuario;
        this.name_usuario = name_usuario;
        this.last_name_usuario = last_name_usuario;
        this.email_usuario = email_usuario;
        this.password_usuario = password_usuario;
        this.edad = edad;
        this.status = status;
        this.id_rol = id_rol;
    }

    public Integer getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(Integer id_usuario) {
        this.id_usuario = id_usuario;
    }

    public String getName_usuario() {
        return name_usuario;
    }

    public void setName_usuario(String name_usuario) {
        this.name_usuario = name_usuario;
    }

    public String getLast_name_usuario() {
        return last_name_usuario;
    }

    public void setLast_name_usuario(String last_name_usuario) {
        this.last_name_usuario = last_name_usuario;
    }

    public String getEmail_usuario() {
        return email_usuario;
    }

    public void setEmail_usuario(String email_usuario) {
        this.email_usuario = email_usuario;
    }

    public String getPassword_usuario() {
        return password_usuario;
    }

    public void setPassword_usuario(String password_usuario) {
        this.password_usuario = password_usuario;
    }

    public Integer getEdad() {
        return edad;
    }

    public void setEdad(Integer edad) {
        this.edad = edad;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public Integer getId_rol() {
        return id_rol;
    }

    public void setId_rol(Integer id_rol) {
        this.id_rol = id_rol;
    }

    @Override
    public String toString() {
        return "Usuario{" +
                "id_usuario=" + id_usuario +
                ", name_usuario='" + name_usuario + '\'' +
                ", last_name_usuario='" + last_name_usuario + '\'' +
                ", email_usuario='" + email_usuario + '\'' +
                ", password_usuario='" + password_usuario + '\'' +
                ", edad=" + edad +
                ", status=" + status +
                ", id_rol=" + id_rol +
                '}';
    }
}
