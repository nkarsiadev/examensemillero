package com.example.api_rest.usuario;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;

@Autowired
    public UsuarioService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }


    public List<Usuario> getUsuarios(){
    return usuarioRepository.findAll();
//        return List.of(new Usuario(
//
//        ));
    }

    public void agregarNuevoUsuario(Usuario usuario) {
    Optional<Usuario> usuarioCorreo =  usuarioRepository.buscarUsuarioCorreo(usuario.getEmail_usuario());
    if (usuarioCorreo.isPresent()){
        throw new IllegalStateException("Correo ya usado");
    }
    usuarioRepository.save(usuario);
    System.out.println(usuario);
    }

    public void borrarUsuario(Integer id_usuario){
        boolean existe = usuarioRepository.existsById(id_usuario);
        if (!existe){
            throw new IllegalStateException(
                    "Usuario con la cedula " + id_usuario + "no existe");

        }
        usuarioRepository.deleteById(id_usuario);
    }

//    public List<Usuario> getUsuariosLogin(String email_usuario, String password_usuario) {
//        usuarioRepository.findBy()
//    }
}
