package com.example.api_rest.roles;

import javax.persistence.*;

@Entity
@Table
public class Roles {

    @Id
    @SequenceGenerator(
            name="secuencia_rol",
            sequenceName = "secuencia_rol",
            allocationSize = 1
    )
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "secuencia_rol"
    )

    private Integer id_rol;
    private String name_rol;
    private String status_rol;

    public Roles() {
    }

    public Roles(Integer id_rol, String name_rol, String status_rol) {
        this.id_rol = id_rol;
        this.name_rol = name_rol;
        this.status_rol = status_rol;
    }

    public Integer getId_rol() {
        return id_rol;
    }

    public void setId_rol(Integer id_rol) {
        this.id_rol = id_rol;
    }

    public String getName_rol() {
        return name_rol;
    }

    public void setName_rol(String name_rol) {
        this.name_rol = name_rol;
    }

    public String getStatus_rol() {
        return status_rol;
    }

    public void setStatus_rol(String status_rol) {
        this.status_rol = status_rol;
    }

    @Override
    public String toString() {
        return "Roles{" +
                "id_rol=" + id_rol +
                ", name_rol='" + name_rol + '\'' +
                ", status_rol='" + status_rol + '\'' +
                '}';
    }
}
