﻿namespace Web_Project.Controllers
{
    public class UserDetails
    {
    }
}