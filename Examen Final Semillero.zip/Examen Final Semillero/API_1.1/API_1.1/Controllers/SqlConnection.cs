﻿namespace Web_Project.Controllers
{
    internal class SqlConnection
    {
    }
}