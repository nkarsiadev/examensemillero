﻿using System.ComponentModel.DataAnnotations;

namespace API_1._1.MODELS
{
    public class USUARIOS
    {
        [Key]
        public int ID_USUARIO { get; set; }
        public string NOMBRE_USUARIO { get; set; }
        public string APELLIDO_USUARIO { get; set; }
        public string CORREO_USUARIO { get; set; }
        public string CONTRASEÑA_USUARIO { get; set; }
        public string STATUS_USUARIO { get; set; }

    }
}
