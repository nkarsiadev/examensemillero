﻿using API_EXAMEN_FINAL.MODELS;

namespace API_EXAMEN_FINAL.Controllers
{
    public class USUARIOS
    {
       
        public int ID_USUARIO { get; set; }
        public string NOMBRE_USUARIO { get; set; }
        public string APELLIDO_USUARIO { get; set; }
        public string CORREO_USUARIO { get; set; }
        public string rol_USUARIO { get; set; }
        public string CONTRASEÑA_USUARIO { get; set; }
        public string EDAD_USUARIO { get; set; }
        public string STATUS_USUARIO { get; set; }
        public int ID_ROL_USUARIO { get; set; }

     
    }
}

